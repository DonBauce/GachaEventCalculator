import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Set the page title and icon
st.set_page_config(
    page_title="Gacha Event Calculator",
    page_icon="🎮",
    layout="wide"
)

# Title and description
st.title("🎮 Gacha Event Calculator")
st.write("""
This calculator helps you simulate gacha game event outcomes based on your current resources.
Enter your starting parameters below and see how many points you'll end up with after the simulation.
""")

class GachaEventCalculator:
    def __init__(self):
        # Define the rounds and their respective costs and rewards
        self.rounds = [
            {'cost': 10, 'reward': {'Iron': 1}},
            {'cost': 20, 'reward': {'Iron': 1}},
            {'cost': 30, 'reward': {'Steel': 1}},
            {'cost': 40, 'reward': {'Silver': 1}},
            {'cost': 80, 'reward': {'Silver': 1}},
            {'cost': 100, 'reward': {'Silver': 1}},
            {'cost': 70, 'reward': {'Steel': 1}},
            {'cost': 50, 'reward': {'Silver': 1}},
            {'cost': 100, 'reward': {}}  # No reward
        ]
        # Point values for each hammer type
        self.point_values = {
            'Wooden': 1,
            'Iron': 10,
            'Steel': 20,
            'Silver': 50
        }

    def simulate(self, start_points, current_round, wooden_hammers, iron_hammers, steel_hammers, silver_hammers):
        # Initialize tracking variables for detailed simulation
        total_points = start_points
        
        # Current hammer inventory (combination of initial and event-earned)
        hammer_inventory = {
            'Wooden': wooden_hammers,
            'Iron': iron_hammers,
            'Steel': steel_hammers,
            'Silver': silver_hammers
        }
        
        # Track hammers earned during the event
        event_earned_hammers = {
            'Wooden': 0,
            'Iron': 0,
            'Steel': 0,
            'Silver': 0
        }
        
        # Track total hammers earned during the event (including those already used)
        total_event_earned_hammers = {
            'Wooden': 0,
            'Iron': 0,
            'Steel': 0,
            'Silver': 0
        }
        
        # Create tracking data for visualization
        simulation_data = []
        round_counters = []
        
        # Record initial state
        simulation_data.append({
            'step': 0,
            'round': current_round,
            'points': total_points,
            'wooden': hammer_inventory['Wooden'],
            'iron': hammer_inventory['Iron'],
            'steel': hammer_inventory['Steel'],
            'silver': hammer_inventory['Silver']
        })

        # Start simulation from the current round
        step = 1
        current_loop = 1
        
        # Continue simulation until no hammers are left or until safety limit is reached
        max_steps = 1000  # Safety limit to avoid infinite loops
        step_counter = 0
        
        # Keep track of current round index
        round_idx = current_round
        
        # Main simulation loop - runs until we use all hammers or hit max steps
        while step_counter < max_steps:
            step_counter += 1
            
            # Get the current round data
            round_data = self.rounds[round_idx - 1]  # Adjust for 0-based indexing
            cost = round_data['cost']
            reward = round_data['reward']
            
            # Check if we have enough points for the current round
            if total_points >= cost:
                # We have enough points, complete the round
                total_points -= cost
                
                # Add the rewards to the hammer inventory
                for hammer, amount in reward.items():
                    hammer_inventory[hammer] += amount
                    # Track hammers earned during the event
                    event_earned_hammers[hammer] += amount
                    total_event_earned_hammers[hammer] += amount
                
                # Record state after completing the round
                round_counters.append(f"Loop {current_loop}, Round {round_idx}")
                simulation_data.append({
                    'step': step,
                    'round': round_idx,
                    'points': total_points,
                    'wooden': hammer_inventory['Wooden'],
                    'iron': hammer_inventory['Iron'],
                    'steel': hammer_inventory['Steel'],
                    'silver': hammer_inventory['Silver']
                })
                step += 1
                
                # Move to the next round
                round_idx += 1
                
                # If we've completed all rounds, start a new loop
                if round_idx > len(self.rounds):
                    round_idx = 1
                    current_loop += 1
            else:
                # Not enough points for the current round, need to use a hammer
                # First, check if we have any hammers left
                if any(amount > 0 for amount in hammer_inventory.values()):
                    # Use hammers in order of highest value to lowest
                    hammer_types = ['Silver', 'Steel', 'Iron', 'Wooden']
                    hammer_used = None
                    
                    # Find the first available hammer type
                    for hammer in hammer_types:
                        if hammer_inventory[hammer] > 0:
                            # Use one hammer of this type
                            hammer_inventory[hammer] -= 1
                            hammer_used = hammer
                            
                            # Add points based on the hammer's value
                            points_gained = self.point_values[hammer]
                            total_points += points_gained
                            
                            # Record state after using a hammer
                            round_counters.append(f"Loop {current_loop}, Used {hammer} Hammer")
                            simulation_data.append({
                                'step': step,
                                'round': round_idx,
                                'points': total_points,
                                'round_cost': self.rounds[round_idx-1]['cost'],
                                'round_reward': self.rounds[round_idx-1]['reward'],
                                'current_hammer': hammer_used,
                                'hammer_value': self.point_values[hammer_used],
                                'wooden': hammer_inventory['Wooden'],
                                'iron': hammer_inventory['Iron'],
                                'steel': hammer_inventory['Steel'],
                                'silver': hammer_inventory['Silver']
                            })
                            step += 1
                            break
                    
                    # If no hammer was used (shouldn't happen due to the check), break
                    if not hammer_used:
                        break
                else:
                    # No hammers left, end the simulation
                    break

        return total_points, pd.DataFrame(simulation_data), event_earned_hammers, total_event_earned_hammers

# Create sidebar for inputs
st.sidebar.header("Input Parameters")

# Starting points input
start_points = st.sidebar.number_input(
    "Starting Points",
    min_value=0,
    value=0,
    step=100,
    help="Enter your starting points for the simulation"
)

# Current round input
current_round = st.sidebar.number_input(
    "Current Round",
    min_value=1,
    max_value=9,
    value=1,
    step=1,
    help="Enter your current round in the gacha event (1-9)"
)

# Hammer inputs
st.sidebar.subheader("Initial Hammer Inventory")
wooden_hammers = st.sidebar.number_input("Wooden Hammers (1 point each)", min_value=0, value=0, step=1)
iron_hammers = st.sidebar.number_input("Iron Hammers (10 points each)", min_value=0, value=0, step=1)
steel_hammers = st.sidebar.number_input("Steel Hammers (20 points each)", min_value=0, value=0, step=1)
silver_hammers = st.sidebar.number_input("Silver Hammers (50 points each)", min_value=0, value=0, step=1)

# Information about rounds
with st.expander("Event Round Information", expanded=False):
    calculator = GachaEventCalculator()
    rounds_data = []
    
    for i, round_data in enumerate(calculator.rounds, 1):
        reward_text = ', '.join([f"{amount} {hammer}" for hammer, amount in round_data['reward'].items()]) if round_data['reward'] else "None"
        rounds_data.append({
            "Round": i,
            "Cost": round_data['cost'],
            "Reward": reward_text
        })
    
    st.table(pd.DataFrame(rounds_data))
    
    st.subheader("Hammer Point Values")
    point_values = {
        "Hammer Type": list(calculator.point_values.keys()),
        "Points": list(calculator.point_values.values())
    }
    st.table(pd.DataFrame(point_values))

# Run simulation
if st.button("Run Simulation", type="primary"):
    calculator = GachaEventCalculator()
    
    with st.spinner("Running simulation..."):
        final_points, simulation_df, event_earned_hammers, total_event_earned_hammers = calculator.simulate(
            start_points, 
            current_round, 
            wooden_hammers, 
            iron_hammers, 
            steel_hammers, 
            silver_hammers
        )
        
        # Debug information removed
    
    # Count the number of loops in the simulation
    if not simulation_df.empty:
        total_loops = simulation_df['step'].max() // len(calculator.rounds) if len(calculator.rounds) > 0 else 0
    else:
        total_loops = 0
        
    # Display results
    st.success(f"Simulation completed starting from round {current_round}!")
    
    # Results in columns
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric(
            label="Starting Points", 
            value=start_points
        )
        
        # Initial hammer inventory
        st.subheader("Initial Hammer Inventory")
        hammers_data = {
            "Hammer Type": ["Wooden", "Iron", "Steel", "Silver"],
            "Quantity": [wooden_hammers, iron_hammers, steel_hammers, silver_hammers],
            "Points Value": [wooden_hammers * 1, iron_hammers * 10, steel_hammers * 20, silver_hammers * 50]
        }
        st.table(pd.DataFrame(hammers_data))
        
        # Display hammers earned during the event (including those already used)
        st.subheader("Hammers Earned During Event")
        event_hammers_data = {
            "Hammer Type": ["Wooden", "Iron", "Steel", "Silver"],
            "Quantity": [
                total_event_earned_hammers["Wooden"], 
                total_event_earned_hammers["Iron"], 
                total_event_earned_hammers["Steel"],
                total_event_earned_hammers["Silver"]
            ],
            "Points Value": [
                total_event_earned_hammers["Wooden"] * 1,
                total_event_earned_hammers["Iron"] * 10,
                total_event_earned_hammers["Steel"] * 20,
                total_event_earned_hammers["Silver"] * 50
            ]
        }
        st.table(pd.DataFrame(event_hammers_data))
    
    with col2:
        # Calculate total potential from initial hammers
        initial_hammer_points = (wooden_hammers * 1) + (iron_hammers * 10) + \
                               (steel_hammers * 20) + (silver_hammers * 50)
        
        # Calculate points from hammers earned during the event
        event_hammers_points = (
            total_event_earned_hammers['Wooden'] * 1 + 
            total_event_earned_hammers['Iron'] * 10 + 
            total_event_earned_hammers['Steel'] * 20 + 
            total_event_earned_hammers['Silver'] * 50
        )
        
        # The total points should be: starting points + points from initial hammers + points from event-earned hammers
        total_accumulated = start_points + initial_hammer_points + event_hammers_points
        
        # Use total_accumulated instead of final_points for better accuracy
        st.metric(
            label="Final Points", 
            value=total_accumulated
        )
        
        # Calculate event cycles (every 8000 points is one cycle, max 4 cycles)
        cycles_completed = min(total_accumulated // 8000, 4)
        max_cycles = 4
        st.metric(
            label="Cycles Completed", 
            value=f"{cycles_completed}/{max_cycles}"
        )
        
        st.subheader("Points Analysis")
        st.write(f"Starting points: {start_points}")
        st.write(f"Points from initial hammers: {initial_hammer_points}")
        st.write(f"Points from event-earned hammers: {event_hammers_points}")
        st.write(f"Total points: {total_accumulated}")
        
        # Show a summary of the simulation
        st.subheader("Simulation Summary")
        st.write(f"- Started with {wooden_hammers + iron_hammers + steel_hammers + silver_hammers} hammers")
        st.write(f"- Earned {sum(total_event_earned_hammers.values())} hammers during the event")
        st.write(f"- Points increased by {total_accumulated - start_points} from starting points")

    # Visualization of points throughout the simulation
    st.subheader("Points Throughout Simulation")
    
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(simulation_df['step'], simulation_df['points'], marker='o', linestyle='-', color='blue')
    
    # Add horizontal lines for cycle boundaries
    cycle_colors = ['green', 'orange', 'red', 'purple']
    for i in range(1, 5):
        cycle_points = i * 8000
        ax.axhline(y=cycle_points, color=cycle_colors[i-1], linestyle='--', 
                 label=f'Cycle {i} ({cycle_points} points)')
    
    ax.set_xlabel('Simulation Step')
    ax.set_ylabel('Points')
    ax.set_title('Points Progress Throughout Simulation')
    ax.legend(loc='upper left')
    ax.grid(True)
    st.pyplot(fig)
    
    # Show hammer acquisitions over time
    st.subheader("Hammer Inventory Throughout Simulation")
    
    hammer_cols = ['wooden', 'iron', 'steel', 'silver']
    hammer_fig, ax = plt.subplots(figsize=(10, 6))
    
    for hammer in hammer_cols:
        ax.plot(simulation_df['step'], simulation_df[hammer], label=hammer.capitalize())
    
    ax.set_xlabel('Simulation Step')
    ax.set_ylabel('Quantity')
    ax.set_title('Hammer Inventory Throughout Simulation')
    ax.legend()
    ax.grid(True)
    st.pyplot(hammer_fig)
    
    # Display detailed simulation data with explanation
    with st.expander("Detailed Simulation Data - Step by Step Breakdown", expanded=False):
        st.markdown("""
        ### Understanding the Simulation Data
        
        This table shows the step-by-step progression of your event:
        
        - **step**: Each simulation step (one hammer used per step)
        - **round**: Which round you're currently on (1-9)
        - **points**: Your total accumulated points at this step
        - **wooden/iron/steel/silver**: Your hammer inventory at each step
        - **current_hammer**: Which hammer type was used at this step
        - **hammer_value**: How many points this hammer contributed
        - **round_cost**: How many points are needed to complete the current round
        - **round_reward**: What reward (hammer) you get for completing the round
        
        The simulation ends when all hammers are used up.
        """)
        
        # Sort the columns in a more logical order
        if not simulation_df.empty:
            column_order = [
                'step', 'round', 'points', 'round_cost', 'round_reward',
                'current_hammer', 'hammer_value', 
                'wooden', 'iron', 'steel', 'silver'
            ]
            
            # Only include columns that exist in the dataframe
            available_columns = [col for col in column_order if col in simulation_df.columns]
            
            # Add any columns that exist in the dataframe but aren't in our ordered list
            for col in simulation_df.columns:
                if col not in available_columns:
                    available_columns.append(col)
            
            # Display the reordered dataframe
            st.dataframe(simulation_df[available_columns])

# Reset button
if st.sidebar.button("Reset All Inputs"):
    # This is a placeholder, as we need to use session state to properly implement this
    st.sidebar.info("To reset all inputs, please refresh the page.")

# Footer with instructions
st.markdown("---")
st.markdown("""
### How to Use This Calculator
1. Enter your starting points and your current round in the gacha event
2. Input any hammers you already have in your inventory
3. Click "Run Simulation" to see the results
4. Track your progress through the event cycles (1 cycle = 8000 points)
5. Use the expandable sections to view detailed information

This calculator helps you plan your gacha event strategy by showing how many points you'll
accumulate until you run out of hammers. The simulation starts from your specified current
round and continues until all hammers are spent.

### About Event Cycles
- Each cycle requires 8000 points to complete
- You can complete a maximum of 4 cycles in the event
- The horizontal lines on the chart show when you'll reach each cycle
- The "Cycles Completed" metric shows your progress toward the maximum of 4 cycles
""")
